// JavaScript Document
var homeslider = '',promotionslider = '',smallscreenslider = '',homesbeaconslider = '',productSliderInr = '',homenav = false,whynav = false,beaconsnav = false,ARnav = false,productnav = false,contactnav = false;
$(document).ready(function(e) {
	handleBrowser();
	if ( $(window).width() < 500) {      
  //Add your javascript for large screens here 
  
	$('.nava_list a, .footer-menu-row a').click(function(){
		var ele = $(this).attr('rel');
		var eleTop = $('#'+ele).offset().top;
		$('.nava_list a, .footer-menu-row a').removeClass('active');
		$(this).addClass('active')
		if(ele == 'why'){
			$('body,html').animate({'scrollTop':'1150px'},600);
		}else if(ele == 'home'){
			$('body,html').animate({'scrollTop':'0'},600);
		}else if(ele == 'contact'){
			$('body,html').animate({'scrollTop':'8028px'},600);
		}else if(ele == 'beacons'){
			$('body,html').animate({'scrollTop':'3880px'},600);
		}else if(ele == 'product'){
			$('body,html').animate({'scrollTop':'7600px'},600);
		}else if(ele == 'AR'){
			$('body,html').animate({'scrollTop':'6000px'},600);
		}else{
			$('body,html').animate({'scrollTop':eleTop+'px'},600);
		}
	});
	
   $(".nava_list").click(function(){
     $(".navigation_main").hide();
});
} 
else {

  //Add your javascript for small screens here 

	$('.nava_list a, .footer-menu-row a').click(function(){
		var ele = $(this).attr('rel');
		var eleTop = $('#'+ele).offset().top;
		$('.nava_list a, .footer-menu-row a').removeClass('active');
		$(this).addClass('active')
		if(ele == 'why'){
			$('body,html').animate({'scrollTop':'420px'},600);
		}else if(ele == 'home'){
			$('body,html').animate({'scrollTop':'0'},600);
		}else if(ele == 'contact'){
			$('body,html').animate({'scrollTop':'9128px'},600);
		}else if(ele == 'beacons'){
			$('body,html').animate({'scrollTop':'3480px'},600);
		}else if(ele == 'product'){
			$('body,html').animate({'scrollTop':'7500px'},600);
		}else if(ele == 'AR'){
			$('body,html').animate({'scrollTop':'5500px'},600);
		}else{
			$('body,html').animate({'scrollTop':eleTop+'px'},600);
		}
	});
}
	$(window).load(function(){
		var s = skrollr.init({
			smoothScrollingDuration:600
		});
	});
	$(window).scroll(function(){
		var scrollTop = $(window).scrollTop();
		navscroll(scrollTop);
			if ( $(window).width() < 500) {    
			$(window).scroll(function(event){
  didScroll = true;
   $(".main_logo").hide();

});
			}
	})
	jQuery.rsCSS3Easing.easeOutBack = 'cubic-bezier(0.175, 0.885, 0.320, 1.275)';
	if($('.top_home_slider').length){
		homeslider = $('.top_home_slider').royalSlider({
			arrowsNav: false,
			keyboardNavEnabled: false,
			controlsInside: false,
			imageScaleMode: 'fill',
			arrowsNavAutoHide: false,
			autoScaleSlider: true, 
			autoScaleSliderWidth: 1920,     
			autoScaleSliderHeight: 1080,
			controlNavigation: 'none',
			thumbsFitInViewport: false,
			navigateByClick: false,
			imageAlignCenter : true,
			transitionType:'move',
			slidesSpacing : 0
					
		}).data('royalSlider');
	}
	if($('.beacon_slider').length){
		homesbeaconslider = $('.beacon_slider').royalSlider({
			arrowsNav: false,
			keyboardNavEnabled: false,
			controlsInside: false,
			imageScaleMode: 'fill',
			arrowsNavAutoHide: false,
			autoScaleSlider: true, 
			autoScaleSliderWidth: 1920,     
			autoScaleSliderHeight: 1080,
			controlNavigation: 'none',
			thumbsFitInViewport: false,
			navigateByClick: false,
			imageAlignCenter : true,
			transitionType:'move',
			slidesSpacing : 0
					
		}).data('royalSlider');
	}
	if($('.promotion_slider').length){
		promotionslider = $('.promotion_slider').royalSlider({
			arrowsNav: false,
			keyboardNavEnabled: false,
			controlsInside: false,
			imageScaleMode: 'fill',
			arrowsNavAutoHide: false,
			autoScaleSlider: true, 
			autoScaleSliderWidth: 1920,     
			autoScaleSliderHeight: 1080,
			controlNavigation: 'none',
			thumbsFitInViewport: false,
			navigateByClick: false,
			imageAlignCenter : true,
			transitionType:'move',
			slidesSpacing : 0
					
		}).data('royalSlider');
	}
	if($('.small_screen_beacon').length){
		smallscreenslider = $('.small_screen_beacon').royalSlider({
			arrowsNav: false,
			keyboardNavEnabled: false,
			controlsInside: false,
			imageScaleMode: 'fill',
			arrowsNavAutoHide: false,
			autoScaleSlider: true, 
			autoScaleSliderWidth: 1920,     
			autoScaleSliderHeight: 1080,
			controlNavigation: 'none',
			thumbsFitInViewport: false,
			navigateByClick: false,
			imageAlignCenter : true,
			transitionType:'move',
			slidesSpacing : 0
						
		}).data('royalSlider');
	}
	if($('.product-slider-inr').length){
		productSliderInr = $('.product-slider-inr').royalSlider({
			arrowsNav: false,
			keyboardNavEnabled: false,
			controlsInside: false,
			imageScaleMode: 'fill',
			arrowsNavAutoHide: false,
			autoScaleSlider: true,
			controlNavigation: 'none',
			thumbsFitInViewport: false,
			navigateByClick: false,
			imageAlignCenter : true,
			transitionType:'move',
			addActiveClass:true,
			slidesSpacing : 0,
			loop : true
					
		}).data('royalSlider');
		
		productSliderInr.ev.on('rsAfterSlideChange', function(event) {
			var targetIndex = $(".rsActiveSlide").index();
			$('.product-img-box').stop(true,true).removeClass("show").fadeOut(1000);
			$('.product-img-box').stop(true,true).eq(targetIndex).addClass('show').fadeIn(2000);
		});
		
	}
	$(".contact_bg").backstretch("images/contact-part-bg.jpg");
	$('.slad_img').backstretch("images/slad_book.jpg");
	$('.nav_button').off('click').on('click',function(){
		var $this = $(this);
		if($this.hasClass('open')){
			$this.removeClass('open');
			$('.navigation_main').stop(true,true).slideUp();
						
		}else{
			$this.addClass('open');
			$('.navigation_main').stop(true,true).slideDown()
		}
	});
	$('.popup_style_select').sSelect();
	
	 $('.popup_request').magnificPopup({
		type: 'inline',
		fixedContentPos: false,
		fixedBgPos: true,
		overflowY: 'auto',
		closeBtnInside: true,
		preloader: false,
		midClick: true,
		removalDelay: 300,
		mainClass: 'my-mfp-zoom-in',
		closeMarkup : '<a href="javascript:;" class="popup_close_btn mfp-close"></a>',
		callbacks: {
			
			open: function() {
			  	$('.popup_style_select').resetSS();
			},
			beforeOpen: function() {
				$('.succes_msg_popup').hide();
				$('input[type=text], textarea, select').val('');
		  	}
		}
	});
});
function navscroll(scrollTop){
	if(scrollTop >= 0 && scrollTop < 420 && !homenav){
			$('.nava_list a').removeClass('active')
			$('.nava_list a[rel=home]').addClass('active');
			whynav = false;homenav = true;beaconsnav = false;ARnav = false;productnav = false;contactnav = false;
		}
		if(scrollTop >= 420 && scrollTop < 3480 && !whynav){
			$('.nava_list a').removeClass('active')
			$('.nava_list a[rel=why]').addClass('active')
			whynav = true;homenav = false;beaconsnav = false;ARnav = false;productnav = false;contactnav = false;
		}
		if(scrollTop >= 3480 && scrollTop < 5881 && !beaconsnav){
			$('.nava_list a').removeClass('active')
			$('.nava_list a[rel=beacons]').addClass('active');
			whynav = false;homenav = false;beaconsnav = true;ARnav = false;productnav = false;contactnav = false;
		}
		if(scrollTop >= 5881 && scrollTop < 7805 && !ARnav){
			$('.nava_list a').removeClass('active')
			$('.nava_list a[rel=AR]').addClass('active');
			whynav = false;homenav = false;beaconsnav = false;ARnav = true;productnav = false;contactnav = false;
		}
		if(scrollTop >= 7805 && scrollTop < 9128 && !productnav){
			$('.nava_list a').removeClass('active')
			$('.nava_list a[rel=product]').addClass('active');
			whynav = false;homenav = false;beaconsnav = false;ARnav = false;productnav = true;contactnav = false;
		}
		if(scrollTop >= 9128 && !contactnav){
			$('.nava_list a').removeClass('active')
			$('.nava_list a[rel=contact]').addClass('active');
			whynav = false;homenav = false;beaconsnav = false;ARnav = false;productnav = false;contactnav = true;
		}
}

function handleBrowser(){//for handle ie browser
	var appVersion = navigator.appVersion, root = $('html');
	var clas= $('p.class')
	if(appVersion.indexOf("MSIE 6.") !== -1){root.addClass('ie ltie11 ltie10 ltie9 ltie8 ltie7 ie6'); clas.text('Browser is ie6'); } 
	if(appVersion.indexOf("MSIE 7.") !== -1){root.addClass('ie ltie11 ltie10 ltie9 ltie8 ie7'); clas.text('Browser is ie7'); } 
	if(appVersion.indexOf("MSIE 8.") !== -1){root.addClass('ie ltie11 ltie10 ltie9 ie8'); clas.text('Browser is ie8');} else
	if(appVersion.indexOf("MSIE 9.") !== -1){root.addClass('ie ltie11 ltie10 ie9'); clas.text('Browser is ie9');} else
	if(appVersion.indexOf("MSIE 10.")!== -1){root.addClass('ie ltie11 ie10'); clas.text('Browser is ie10');} else
	if(appVersion.indexOf("MSIE 11.")!== -1){root.addClass('ie ie11'); clas.text('Browser is ie11');}
}